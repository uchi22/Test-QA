<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add Item</name>
   <tag></tag>
   <elementGuidId>db559d85-dd11-42f4-b3ae-2ff982b17716</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@onclick = 'addItem()']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>[onclick=&quot;addItem\(\)&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>2f4a9e24-0c42-4d14-abac-f61eb559dd1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>addItem()</value>
      <webElementGuid>48e121e1-39b0-4243-92e4-10242626d28e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add Item</value>
      <webElementGuid>e07e8f59-dbe7-4674-be2e-f352b3e1e22c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>parent</name>
      <type>Main</type>
      <value>md5.v1-2563a081bbf0cd07ea74be5a34a0bae6</value>
      <webElementGuid>035cf00c-5a30-4ba7-87e5-cfef7f32be61</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@onclick = 'addItem()']</value>
      <webElementGuid>c084904d-56d4-4e04-927d-b68959ee7e42</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//*[@onclick = 'addItem()']</value>
      <webElementGuid>68d4a0a9-d859-4d18-a41a-3d92d1811b3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Add Item' or . = 'Add Item')]</value>
      <webElementGuid>23a8b751-f541-4cca-ac3d-fd76479f520c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
