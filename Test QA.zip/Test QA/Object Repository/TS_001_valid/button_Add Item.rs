<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Add Item</name>
   <tag></tag>
   <elementGuidId>4009336d-a4c9-45bc-a88e-5c36e75eb07d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@onclick = 'addItem()']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>[onclick=&quot;addItem\(\)&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>29e93515-f531-41f9-a1f9-38fc45b84d58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>addItem()</value>
      <webElementGuid>e477e78a-ae0f-4a8e-ba42-e89be150d5a1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add Item</value>
      <webElementGuid>03b3e1f2-ec24-4530-a478-0bf4559aa94a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>parent</name>
      <type>Main</type>
      <value>md5.v1-2563a081bbf0cd07ea74be5a34a0bae6</value>
      <webElementGuid>1717c295-5106-4b4a-b441-37fcde242413</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@onclick = 'addItem()']</value>
      <webElementGuid>93b6b946-cfa1-42fe-a166-18830d1d743c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//*[@onclick = 'addItem()']</value>
      <webElementGuid>6ba6b6f2-2d1e-41ae-a977-5d1fa1d1822f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'Add Item' or . = 'Add Item')]</value>
      <webElementGuid>fb0f2ddc-da67-44ef-be13-dd00e5f1cd1f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
