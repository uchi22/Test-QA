import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('file:///Users/ucikheni/Downloads/index2.html')

WebUI.setText(findTestObject('TS_001_valid/input_Product Name'), Items)

WebUI.setText(findTestObject('TS_001_valid/input_Price'), Price)

WebUI.setText(findTestObject('TS_001_valid/input_Quantity'), Quantity)

WebUI.click(findTestObject('TS_001_valid/button_Add Item'))

if (Expected == 'Valid') {
    // Jika valid, verifikasi item berhasil masuk ke tabel
    WebUI.verifyElementPresent(findTestObject('Object Repository/Table_Row_Item', [('name') : var_product_name]), 5) // (Opsional) Hapus item agar tabel kembali bersih untuk test selanjutnya
    // WebUI.click(findTestObject('Object Repository/Btn_Delete_Item'))
    // Jika invalid, verifikasi pesan error muncul atau item tidak masuk tabel
    // Ubah object di bawah dengan notifikasi error yang ada di aplikasi Anda
} else if (Expected == 'Invalid') {
    WebUI.verifyElementPresent(findTestObject('Object Repository/Error_Message'), 5)
}

// Clear text untuk perulangan selanjutnya (opsional jika halaman di-refresh)
WebUI.refresh()

