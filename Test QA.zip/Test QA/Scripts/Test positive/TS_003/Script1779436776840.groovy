import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('file:///Users/ucikheni/Downloads/index2.html')

String items = 'Cangkir'

int harga = 3500

int quantity = 3

double subtotal = harga * quantity

double ppn = subtotal * 0.11

double grandtotal = subtotal + ppn

WebUI.setText(findTestObject('TS_001_valid/input_Product Name'), items)

WebUI.setText(findTestObject('TS_001_valid/input_Price'), String.valueOf(harga))

WebUI.setText(findTestObject('TS_001_valid/input_Quantity'), String.valueOf(quantity))

WebUI.click(findTestObject('TS_001_valid/button_Add Item'))

String grandtotal = "";

String angkatotal =grandtotal.replaceAll("[^0-9.]","")
double aktgrandtotal = double.parseDouble(angkatotal)

if(grandtotal) ekspektasigrandtotal{
	keywordUtil.markFailed("PASSED : KALKULASI GRAND TOTAL. NILAI:"+ aktgrandtotal)
}else{
	keywordUtil.markFailed("FAILED : Perhitungan pajak. NILAI:"+ ekspektasigrandtotal)	
}
