import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('file:///Users/ucikheni/Downloads/index2.html')

WebUI.setText(findTestObject('TN_002_failed/input_Inventory Manager_itemName'), 'Tas')

WebUI.setText(findTestObject('TN_002_failed/input_Inventory Manager_itemPrice'), '12000')

WebUI.setText(findTestObject('TN_002_failed/input_Inventory Manager_itemQty'), '1')

WebUI.click(findTestObject('TN_002_failed/button_Add Item'))

// 1. Ambil teks nilai Subtotal dari baris tabel
String teksSubtotal = WebUI.getText(findTestObject('TN_002_failed/td_-12000'))

double subtotal = Double.parseDouble(teksSubtotal)

// 2. Hitung ekspektasi Total secara matematis (Subtotal + 11%)
double ekspektasiTotal = subtotal + (subtotal * 0.11)

// 3. Ambil keseluruhan teks Total dari layar 
// (Biasanya akan mengambil string seperti: "Total (Inc. Tax 11%): -2553.00")
String teksTotalUI = WebUI.getText(findTestObject('span_grandTotal'))

// 4. Bersihkan teks dari UI agar hanya menyisakan angkanya saja
// Sesuaikan teks di dalam tanda kutip replace jika format aslinya berbeda spasi
String teksAngkaSaja = teksTotalUI.replace('Total (Inc. Tax 11%): ', '').trim()

double aktualTotal = Double.parseDouble(teksAngkaSaja)

// 5. Verifikasi apakah hasil perhitungan sistem sama dengan rumus matematika
// Menggunakan toleransi selisih 0.01 untuk menghindari gagal karena isu pembulatan desimal (floating point)
assert Math.abs(aktualTotal - ekspektasiTotal) < 0.01

